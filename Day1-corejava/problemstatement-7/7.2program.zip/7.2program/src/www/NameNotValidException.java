package www;

public class NameNotValidException extends Exception {

	}
