package www;


public class AgeNotWithInRangeException extends Exception {

	

}
